module.exports = function () { return {}; };
